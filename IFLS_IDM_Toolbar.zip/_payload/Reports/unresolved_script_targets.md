# Unresolved script targets referenced by toolbars

Total unresolved: **36**

## Scripts/IfeelLikeSnow/DF95/DF95_Menu_Humanize_Dropdown.lua
- Referenced in: `Menus/DF95_CoToolbar.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Menu_Humanize_Dropdown.lua`
  - `Scripts/IFLS/DF95/Design/DF95_Menu_Humanize_Dropdown.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_Menu_Coloring_Dropdown.lua
- Referenced in: `Menus/DF95_CoToolbar.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Menu_Coloring_Dropdown.lua`
  - `Scripts/IFLS/DF95/Tools/DF95_Menu_Coloring_Dropdown.lua`

## Scripts/IfeelLikeSnow/DF95/Design/DF95_Slice_Menu.lua
- Referenced in: `Menus/DF95_CoToolbar_Context.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Slice_Menu.lua`
  - `Scripts/IFLS/DF95/Design/DF95_Slice_Menu.lua`

## Scripts/IfeelLikeSnow/DF95/Design/DF95_Menu_Humanize_Dropdown.lua
- Referenced in: `Menus/DF95_CoToolbar_Context.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Menu_Humanize_Dropdown.lua`
  - `Scripts/IFLS/DF95/Design/DF95_Menu_Humanize_Dropdown.lua`

## Scripts/IfeelLikeSnow/DF95/Design/DF95_FXBus_Seed.lua
- Referenced in: `Menus/DF95_CoToolbar_Context.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_FXBus_Seed.lua`
  - `Scripts/IFLS/DF95/Design/DF95_FXBus_Seed.lua`

## Scripts/IfeelLikeSnow/DF95/Design/DF95_LoopBuilder.lua
- Referenced in: `Menus/DF95_CoToolbar_Context.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_LoopBuilder.lua`
  - `Scripts/IFLS/DF95/Design/DF95_LoopBuilder.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_Slice_Menu.lua
- Referenced in: `Menus/DF95_CoToolbar_EditCreative.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Slice_Menu.lua`
  - `Scripts/IFLS/DF95/Design/DF95_Slice_Menu.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_FXBus_Seed.lua
- Referenced in: `Menus/DF95_CoToolbar_EditCreative.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_FXBus_Seed.lua`
  - `Scripts/IFLS/DF95/Design/DF95_FXBus_Seed.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_LoopBuilder.lua
- Referenced in: `Menus/DF95_CoToolbar_EditCreative.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_LoopBuilder.lua`
  - `Scripts/IFLS/DF95/Design/DF95_LoopBuilder.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_Rearrange_Align.lua
- Referenced in: `Menus/DF95_CoToolbar_EditCreative.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Rearrange_Align.lua`
  - `Scripts/IFLS/DF95/Edit/DF95_Rearrange_Align.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_Explode_AutoBus.lua
- Referenced in: `Menus/DF95_CoToolbar_FlowErgo_Pro.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Explode_AutoBus.lua`
  - `Scripts/IFLS/DF95/Core/DF95_Explode_AutoBus.lua`

## Scripts/IfeelLikeSnow/DF95/Tools/DF95_MicFX_Profile_GUI.lua
- Referenced in: `Menus/DF95_CoToolbar_FlowErgo_Pro.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_MicFX_Profile_GUI.lua`
  - `Scripts/IFLS/DF95/Tools/DF95_MicFX_Profile_GUI.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_FXBus_Selector.lua
- Referenced in: `Menus/DF95_CoToolbar_FlowErgo_Pro.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_FXBus_Selector.lua`
  - `Scripts/IFLS/DF95/Core/DF95_FXBus_Selector.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_GainMatch_AB.lua
- Referenced in: `Menus/DF95_CoToolbar_FlowErgo_Pro.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_GainMatch_AB.lua`
  - `Scripts/IFLS/DF95/Input/DF95_GainMatch_AB.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_Menu_Master_Dropdown.lua
- Referenced in: `Menus/DF95_CoToolbar_FlowErgo_Pro.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Menu_Master_Dropdown.lua`
  - `Scripts/IFLS/DF95/Tools/DF95_Menu_Master_Dropdown.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_FirstRun_LiveCheck.lua
- Referenced in: `Menus/DF95_CoToolbar_FlowErgo_Pro.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_FirstRun_LiveCheck.lua`
  - `Scripts/IFLS/DF95/QA/DF95_FirstRun_LiveCheck.lua`

## Scripts/IfeelLikeSnow/DF95/Edit/DF95_Rearrange_Align.lua
- Referenced in: `Menus/DF95_EditToolbar_Arrange.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Rearrange_Align.lua`
  - `Scripts/IFLS/DF95/Edit/DF95_Rearrange_Align.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_MicFX_Manager.lua
- Referenced in: `Menus/DF95_MainToolbar_FlowErgo.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_MicFX_Manager.lua`
  - `Scripts/IFLS/DF95/Input/DF95_MicFX_Manager.lua`

## Scripts/IfeelLikeSnow/DF95/Tools/DF95_Menu_FXBus_Dropdown.lua
- Referenced in: `Menus/DF95_MainToolbar_FlowErgo.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Menu_FXBus_Dropdown.lua`
  - `Scripts/IFLS/DF95/Tools/DF95_Menu_FXBus_Dropdown.lua`

## Scripts/IfeelLikeSnow/DF95/Tools/DF95_Menu_Coloring_Dropdown.lua
- Referenced in: `Menus/DF95_MainToolbar_FlowErgo.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Menu_Coloring_Dropdown.lua`
  - `Scripts/IFLS/DF95/Tools/DF95_Menu_Coloring_Dropdown.lua`

## Scripts/IfeelLikeSnow/DF95/Tools/DF95_Menu_Master_Dropdown.lua
- Referenced in: `Menus/DF95_MainToolbar_FlowErgo.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Menu_Master_Dropdown.lua`
  - `Scripts/IFLS/DF95/Tools/DF95_Menu_Master_Dropdown.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_ColoringBus_Selector.lua
- Referenced in: `Menus/DF95_MainToolbar_FlowErgo_Pro.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_ColoringBus_Selector.lua`
  - `Scripts/IFLS/DF95/Core/DF95_ColoringBus_Selector.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_MasterBus_Selector.lua
- Referenced in: `Menus/DF95_MainToolbar_FlowErgo_Pro.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_MasterBus_Selector.lua`
  - `Scripts/IFLS/DF95/Core/DF95_MasterBus_Selector.lua`

## Scripts/IfeelLikeSnow/DF95/Input/DF95_MicFX_Manager.lua
- Referenced in: `Menus/DF95_MicToolbar_Input.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_MicFX_Manager.lua`
  - `Scripts/IFLS/DF95/Input/DF95_MicFX_Manager.lua`

## Scripts/IfeelLikeSnow/DF95/Input/DF95_GainMatch_AB.lua
- Referenced in: `Menus/DF95_MicToolbar_Input.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_GainMatch_AB.lua`
  - `Scripts/IFLS/DF95/Input/DF95_GainMatch_AB.lua`

## Scripts/IfeelLikeSnow/DF95/QA/DF95_Safety_Loudness_Menu.lua
- Referenced in: `Menus/DF95_QA_Toolbar_Safety.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Safety_Loudness_Menu.lua`
  - `Scripts/IFLS/DF95/QA/DF95_Safety_Loudness_Menu.lua`

## Scripts/IfeelLikeSnow/DF95/QA/DF95_FirstRun_LiveCheck.lua
- Referenced in: `Menus/DF95_QA_Toolbar_Safety.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_FirstRun_LiveCheck.lua`
  - `Scripts/IFLS/DF95/QA/DF95_FirstRun_LiveCheck.lua`

## Scripts/IfeelLikeSnow/DF95/DF95_Fieldrec_Slicing_Hub_ImGui.lua
- Referenced in: `Menus/DF95_SuperToolbar_FIELDREC_Sub.ReaperMenuSet`
- Candidates found: 0

## Scripts/IfeelLikeSnow/DF95/DF95_Fieldrec_Fusion_GUI.lua
- Referenced in: `Menus/DF95_SuperToolbar_FIELDREC_Sub.ReaperMenuSet`
- Candidates found: 0

## Scripts/IfeelLikeSnow/DF95/DF95_InputFX_Metering.lua
- Referenced in: `Menus/DF95_SuperToolbar_SESSION_Sub.ReaperMenuSet`
- Candidates found: 0

## Scripts/IfeelLikeSnow/DF95/DF95_InputFX_TapeColor.lua
- Referenced in: `Menus/DF95_SuperToolbar_SESSION_Sub.ReaperMenuSet`
- Candidates found: 0

## Scripts/IfeelLikeSnow/DF95/DF95_DroneFXV1_Repo_AutoInstaller.lua
- Referenced in: `Menus/DF95_SuperToolbar_SETUPQA_Sub.ReaperMenuSet`
- Candidates found: 0

## Scripts/IfeelLikeSnow/DF95/DF95_Safety_Inspector_ImGui.lua
- Referenced in: `Menus/DF95_SuperToolbar_SETUPQA_Sub.ReaperMenuSet`
- Candidates found: 0

## Scripts/IfeelLikeSnow/DF95/Tools/DF95_Toolbar_BiasTools_Show.lua
- Referenced in: `Menus/DF95_SuperToolbar_SOUND_Sub.ReaperMenuSet`
- Candidates found: 0

## Scripts/IfeelLikeSnow/DF95/Tools/DF95_Toolbar_ColorMaster_Audition_SWS_Show.lua
- Referenced in: `Menus/DF95_SuperToolbar_SOUND_Sub.ReaperMenuSet`
- Candidates found: 0

## Scripts/IfeelLikeSnow/DF95/DF95_Safety_Loudness_Menu.lua
- Referenced in: `Menus/Legacy_46c/DF95_MainToolbar.ReaperMenuSet`
- Candidates found: 2
  - `Scripts/IFLS/DF95/DF95_Safety_Loudness_Menu.lua`
  - `Scripts/IFLS/DF95/QA/DF95_Safety_Loudness_Menu.lua`

