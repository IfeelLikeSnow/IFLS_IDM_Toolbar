# Icon resolution report

Placeholder icons created in `Data/toolbar_icons/`: **0**


## References (toolbar -> icon)

