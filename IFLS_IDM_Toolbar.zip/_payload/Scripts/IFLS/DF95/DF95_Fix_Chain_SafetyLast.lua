-- @description Fix Chains – SafetyLast (move limiters last / ensure on Master)
-- @version 1.0
-- @author DF95
-- Moves any limiter to last in chain. Ensures ReaLimit at end on Master track.
reaper.ShowMessageBox("SafetyLast is handled offline in v1.48f (rfxchain files). In-session fixer coming next.", "DF95", 0)
