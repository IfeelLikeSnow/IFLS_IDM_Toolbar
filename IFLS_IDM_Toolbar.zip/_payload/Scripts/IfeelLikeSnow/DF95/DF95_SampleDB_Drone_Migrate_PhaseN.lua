-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_SampleDB_Drone_Migrate_PhaseN.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/DF95_SampleDB_Drone_Migrate_PhaseN.lua"
dofile(real)
