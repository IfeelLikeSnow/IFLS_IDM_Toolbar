-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_V138_SampleDB_LibraryAnalyzer.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/DF95_V138_SampleDB_LibraryAnalyzer.lua"
dofile(real)
