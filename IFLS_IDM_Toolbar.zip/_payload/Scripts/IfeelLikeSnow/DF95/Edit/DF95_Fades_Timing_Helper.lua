-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Edit/DF95_Fades_Timing_Helper.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/Edit/DF95_Fades_Timing_Helper.lua"
dofile(real)
