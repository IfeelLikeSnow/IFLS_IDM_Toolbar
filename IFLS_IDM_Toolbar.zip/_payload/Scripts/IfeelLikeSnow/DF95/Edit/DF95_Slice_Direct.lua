-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Edit/DF95_Slice_Direct.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/Edit/DF95_Slice_Direct.lua"
dofile(real)
