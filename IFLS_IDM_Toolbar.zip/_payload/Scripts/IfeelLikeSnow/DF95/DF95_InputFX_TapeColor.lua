-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_InputFX_TapeColor.lua"
-- Could not uniquely resolve to a real script in this repo.
-- Candidates:
--  (no candidates found)
reaper.ShowMessageBox("DF95 Toolbar Suite: Missing or ambiguous script target:
Scripts/IfeelLikeSnow/DF95/DF95_InputFX_TapeColor.lua

See Reports/unresolved_script_targets.md", "DF95 Toolbar Suite", 0)
