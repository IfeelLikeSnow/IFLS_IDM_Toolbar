-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_SuperToolbar_Toggle_DRONES.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/DF95_SuperToolbar_Toggle_DRONES.lua"
dofile(real)
