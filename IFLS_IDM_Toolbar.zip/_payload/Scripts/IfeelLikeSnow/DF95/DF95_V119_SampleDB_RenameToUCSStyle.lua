-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_V119_SampleDB_RenameToUCSStyle.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/DF95_V119_SampleDB_RenameToUCSStyle.lua"
dofile(real)
