-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_AI_FXChain_FullAuto_From_AIResult.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/DF95_AI_FXChain_FullAuto_From_AIResult.lua"
dofile(real)
