-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_Slicing_FadeShape_Set_Fast.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/DF95_Slicing_FadeShape_Set_Fast.lua"
dofile(real)
