-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_SuperToolbar_Toggle_SOUND.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/DF95_SuperToolbar_Toggle_SOUND.lua"
dofile(real)
