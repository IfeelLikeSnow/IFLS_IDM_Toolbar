-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/DF95_Reamp_Latency_Analyze_And_Align.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/DF95_Reamp_Latency_Analyze_And_Align.lua"
dofile(real)
