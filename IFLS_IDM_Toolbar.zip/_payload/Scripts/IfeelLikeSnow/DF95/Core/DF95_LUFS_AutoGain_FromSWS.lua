-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Core/DF95_LUFS_AutoGain_FromSWS.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/Core/DF95_LUFS_AutoGain_FromSWS.lua"
dofile(real)
