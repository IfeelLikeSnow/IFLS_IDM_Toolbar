-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Core/DF95_Menu_Coloring_Dropdown_v2b.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/Core/DF95_Menu_Coloring_Dropdown_v2b.lua"
dofile(real)
