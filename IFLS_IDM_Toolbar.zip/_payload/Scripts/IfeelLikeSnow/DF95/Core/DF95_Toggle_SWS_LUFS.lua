-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Core/DF95_Toggle_SWS_LUFS.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/Core/DF95_Toggle_SWS_LUFS.lua"
dofile(real)
