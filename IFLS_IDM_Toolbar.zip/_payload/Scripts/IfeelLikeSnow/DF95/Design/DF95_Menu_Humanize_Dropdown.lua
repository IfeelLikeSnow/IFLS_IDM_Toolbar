-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Design/DF95_Menu_Humanize_Dropdown.lua"
-- Could not uniquely resolve to a real script in this repo.
-- Candidates:
--  - Scripts/IFLS/DF95/DF95_Menu_Humanize_Dropdown.lua
  - Scripts/IFLS/DF95/Design/DF95_Menu_Humanize_Dropdown.lua
reaper.ShowMessageBox("DF95 Toolbar Suite: Missing or ambiguous script target:
Scripts/IfeelLikeSnow/DF95/Design/DF95_Menu_Humanize_Dropdown.lua

See Reports/unresolved_script_targets.md", "DF95 Toolbar Suite", 0)
