-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Tools/DF95_BiasSnapshot_BoC_Warm.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/Tools/DF95_BiasSnapshot_BoC_Warm.lua"
dofile(real)
