-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Tools/DF95_META_Helper_GUI.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/Tools/DF95_META_Helper_GUI.lua"
dofile(real)
