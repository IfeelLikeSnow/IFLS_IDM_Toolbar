-- Auto-generated shim for toolbar compatibility
-- Toolbar target: "Scripts/IfeelLikeSnow/DF95/Input/DF95_LUFS_AutoTarget.lua"
local real = reaper.GetResourcePath() .. "/Scripts/Scripts/IFLS/DF95/Input/DF95_LUFS_AutoTarget.lua"
dofile(real)
