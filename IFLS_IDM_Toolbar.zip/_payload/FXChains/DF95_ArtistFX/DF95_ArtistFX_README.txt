DF95 Artist/Style FX System (V113 Prototype)
============================================

Diese FXChains sind Platzhalter-Beschreibungen für das Artist+Style-FX-System.
Die eigentliche Instanziierung der FX passiert in:

  Scripts/IFLS/DF95/DF95_V113_ArtistStyleFX_Apply.lua

Die Einträge hier dienen nur als menschlich lesbare Referenz.
