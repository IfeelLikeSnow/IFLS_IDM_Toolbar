DF95 Chain Indexer: Actions -> DF95_Chain_Indexer_v1.lua ausführen, um Data/DF95/DF95_ChainIndex.json zu erzeugen.
Die v2b-Dropdowns lesen den Index und bieten Random (weighted/neutral) + Substitution Loader.
